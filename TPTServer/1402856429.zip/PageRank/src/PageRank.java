import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.output.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.commons.io.FileUtils;


public class PageRank {

	//--------------------------------------------first job----------------------------------------
	enum myCounters{ 
		NUMNODES;
	}

	static class RemoveDeadendsMap extends Mapper<LongWritable, Text, Text, Text> {
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			context.write(new Text("1"), value);
		}
	}


	static class RemoveDeadendsReduce extends Reducer<Text, Text, Text, Text> {

		protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			Counter c = context.getCounter(myCounters.NUMNODES);
			Vector<Integer> vNodes=new Vector<Integer>();
			Vector<Integer> vValues=new Vector<Integer>();
			Vector<Integer> vWrittenNodes=new Vector<Integer>();
			for (Text value : values)
			{
				String[] elements  = value.toString().split("\\s+");
				vNodes.add(Integer.valueOf(elements[0]));
				vValues.add(Integer.valueOf(elements[1]));
			}
			for(int i=0;i<vNodes.size();i++)
			{
				if(vNodes.contains(vValues.elementAt(i))&&vNodes.elementAt(i)!=vValues.elementAt(i))
				{
					context.write(new Text(String.valueOf(vNodes.elementAt(i))), new Text(String.valueOf(vValues.elementAt(i))));
					if(!vWrittenNodes.contains(vNodes.elementAt(i)))
					{
						vWrittenNodes.add(vNodes.elementAt(i));
						c.increment(1);
					}

				}
			}
		}
	}



	public static void removeDeadendsJob(Configuration conf) throws IOException, ClassNotFoundException, InterruptedException{	
		boolean existDeadends = true;
		String intermediaryDir = conf.get("intermediaryDirPath");
		String input = conf.get("processedGraphPath");
		long nNodes = conf.getLong("numNodes", 0);	
		while(existDeadends)
		{

			Job job = Job.getInstance(conf);
			job.setMapOutputKeyClass(Text.class);
			job.setMapOutputValueClass(Text.class);

			job.setMapperClass(RemoveDeadendsMap.class);
			job.setReducerClass(RemoveDeadendsReduce.class);

			job.setInputFormatClass(TextInputFormat.class);
			FileInputFormat.setInputPaths(job, new Path(input));
			FileOutputFormat.setOutputPath(job, new Path(intermediaryDir));
			job.waitForCompletion(true);
			FileUtils.deleteDirectory(new File(input));
			FileUtils.copyDirectory(new File(intermediaryDir), new File(input));
			FileUtils.deleteDirectory(new File(intermediaryDir));

			Counters counters=job.getCounters();
			long nNodesf = counters.findCounter(myCounters.NUMNODES).getValue();
			if (nNodesf==nNodes)
				existDeadends=false;
			nNodes=nNodesf;
			/* in the input you will have the original graph. At the end, the result should be in the same path(processedGraphPath). The result is the graph without the edges of the deadends. this graph is constructed iterativly, until we 
			don't have deadends left. intermediaryDir is used for the iteration steps
			use the counter to check the stop condition */
		}	
		conf.setLong("numNodes", nNodes);

	}



	//--------------------------------------------second job----------------------------------------


	// you can change the types defined for the input and output, but make sure to do the changes in all the necessary places

	static class GraphToMatrixMap extends Mapper<LongWritable, Text, Text, Text> {
		private Text row = new Text();
		private Text element = new Text();
		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			context.write(new Text("1"), value);
		}
	}

	static class GraphToMatrixReduce extends Reducer<Text, Text, Text, Text> {
		private MultipleOutputs<Text,Text> mout;
		public void setup(Context context) {
			mout = new MultipleOutputs<Text,Text>(context);
		}
		public void cleanup(Context context) throws IOException {
			try {
				mout.close();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		protected void reduce(Text key, Iterable<Text> values, Context context){

			Text returnValue = null;
			Text returnKey = null;
			Vector<Integer> vNodes=new Vector<Integer>();
			Vector<Integer> vValues=new Vector<Integer>();
			Vector<Integer> Sums=new Vector<Integer>();
			Vector<Integer> sumsVal=new Vector<Integer>();
			ArrayList<Integer> listNode=new ArrayList<Integer>();
			for (Text value : values)
			{
				String[] elements  = value.toString().split("\\s+");
				vNodes.add(Integer.valueOf(elements[0]));
				vValues.add(Integer.valueOf(elements[1]));
			}
			int sum=0;

			for(int j=0;j<vValues.size();j++)
			{
				sum+=vValues.get(j);
				if(!listNode.contains(vNodes.elementAt(j)))
				{
					listNode.add(vNodes.elementAt(j));
					Sums.add(1);
				}else Sums.setElementAt(Sums.get(listNode.lastIndexOf(vNodes.elementAt(j)))+1,listNode.lastIndexOf(vNodes.elementAt(j)));
			}

			for(int i=0;i<listNode.size();i++)
			{
				
				for(int j=0;j<vValues.size();j++)
				{
					if(vValues.get(j)==listNode.get(i))
					{
						if(sumsVal.size()<i+1)sumsVal.add(vValues.get(j));
						else sumsVal.setElementAt(sumsVal.elementAt(i)+vValues.get(j), i);
						
					}
				}
			}
			for(int i=0;i<listNode.size();i++)
			{
				returnKey=new Text(String.valueOf(listNode.get(i)));
				returnValue=new Text(String.valueOf((double)sumsVal.get(i)/(double)sum));
				//this is how you will write the vector
				try {
					mout.write("vector", returnKey, returnValue, "initialPageRank/");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			for(Iterator<Integer> nodeIt =listNode.iterator();nodeIt.hasNext();)
			{
				int node=nodeIt.next();
				returnKey=new Text(String.valueOf(node));
				for(int i=0;i<vValues.size();i++)
				{
					if(vNodes.get(i)==node){
						returnValue=new Text(String.valueOf(vValues.get(i))+" "+(double)1/(double)Sums.get(listNode.indexOf(node)));

						System.out.println(String.valueOf(vValues.get(i))+" "+(double)1/(double)Sums.get(listNode.indexOf(node)));
						//this is how you will write the matrix
						try {
							mout.write("matrix", returnKey , returnValue, "stochasticMatrix/" );
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 
					}
				}
			}
		}
	} 

	public static void GraphToMatrixJob(Configuration conf)
			throws IOException, ClassNotFoundException, InterruptedException {
		Job job = Job.getInstance(conf);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setMapperClass(GraphToMatrixMap.class);
		job.setReducerClass(GraphToMatrixReduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		MultipleOutputs.addNamedOutput(job, "vector", TextOutputFormat.class,
				Text.class, Text.class);
		MultipleOutputs.addNamedOutput(job, "matrix", TextOutputFormat.class,
				Text.class, Text.class);
		FileInputFormat.setInputPaths(job, new Path(conf.get("processedGraphPath")));
		FileOutputFormat.setOutputPath(job, new Path(conf.get("multipleOutputsPath")));
		job.waitForCompletion(true);
	}



	//--------------------------------------------iteration ----------------------------------------

	public static void avoidSpiderTraps(String vectorDir, long nNodes, double beta) throws IOException
	{
		//TODO
	}


	public static boolean checkConvergence(String initialDir, String iterationDir, double epsilon)	{
		return false;

		//TODO 
	}


	public static void iterativePageRank(Configuration conf) throws ClassNotFoundException, IOException, InterruptedException{
		String initialVector = conf.get("initialPageRankPath");
		String currentVector = conf.get("currentPageRankPath");

		/* here is were the final result should be */
		String finalVector = conf.get("finalPageRankPath"); 

		Double epsilon = conf.getDouble("epsilon", 0.1);
		Double beta = conf.getDouble("beta", 0.8);

		long nNodes = conf.getLong("numNodes", 1);

		PageRank.removeDeadendsJob(conf);
		PageRank.GraphToMatrixJob(conf);
		MatrixVectorMult.multiplicationJob(conf);

	}
}





